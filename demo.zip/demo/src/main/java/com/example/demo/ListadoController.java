package com.example.demo;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import com.example.demo.Alumnado;
import com.example.demo.AlumnadoDAO;


@WebServlet("/api/ListadoController")
public class ListadoController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //Crea la instancia de AlumnadoDAO
        AlumnadoDAO dao = new AlumnadoDAO();

        //Invoco el método listarAlumnos
        List<Alumnado> listado = dao.listarAlumnos();

        //Grabo el listado en el request para verlo en la sigueinte pág
        req.setAttribute("Listado", listado);

        //Ir a la siguiente pág
        getServletContext().getRequestDispatcher("/listado.jps").forward(req, resp);

    }
}
