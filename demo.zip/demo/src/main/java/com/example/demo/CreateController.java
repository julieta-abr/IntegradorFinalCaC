package com.example.demo;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import com.example.demo.AlumnadoDAO;

@WebServlet("/CreateController")
public class CreateController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int Id = Integer.parseInt(request.getParameter("Id"));
        String Nombre = request.getParameter("Nombre");
        String Apellido = request.getParameter("Apellido");
        int dni = Integer.parseInt(request.getParameter("dni"));

        //Crear registro
        AlumnadoDAO dao = new AlumnadoDAO();

        //Ejecutar el método crearAlumno()
        dao.crearAlumno(Id,Nombre, Apellido, dni);

        //ctrl+shift+o
        //Siguiente página
        response.sendRedirect(request.getContextPath()+"/api/ListadoController");
    }
}
