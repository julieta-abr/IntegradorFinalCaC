package com.example.demo;

import java.util.Date;

public class Alumnado {
    private int Id;
    private String Nombre;
    private String Apellido;
    private int dni;


    public Alumnado(int Id, String Nombre, String Apellido, int dni) {
        super();
        this.Id = Id;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.dni = dni;
    }



    //GETTERS Y SETTERS
    public int getId() {
        return Id;
    }
    public void setId(int Id) {
        this.Id = Id;
    }

    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }
    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getDni() {
        return dni;
    }
    public void setDni(int dni) {
        this.dni = dni;
    }
}
