package com.example.demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import com.example.demo.AdministradorDeConexiones;


@WebServlet("/api/EliminarController")
public class EliminarController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String Id = req.getParameter("Id");

        Connection con = AdministradorDeConexiones.getConnection();
        if(con != null) {
            //Delete
            String sql = "DELETE FROM ESTUDIANTES WHERE Id="+Id;

            try {
                Statement st = con.createStatement();
                st.executeUpdate(sql);

                con.close();

                resp.sendRedirect(req.getContextPath()+"/api/ListadoController");
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
