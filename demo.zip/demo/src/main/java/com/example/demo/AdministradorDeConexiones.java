package com.example.demo;
import java.sql.Connection;
import java.sql.DriverManager;

public class AdministradorDeConexiones {
    public static Connection getConnection() {
		String url = "jdbc:mysql://localhost:3306/jdbc?serverTimezone=UTC";
		String user = "root";
		String password = "root";

        //Control de errores
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,user,password);
        }catch(Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public static void main(String[] args) {
        Connection con = AdministradorDeConexiones.getConnection();//F5
        if(con != null) {
            System.out.println("Conectado");
        }else {
            System.err.println("Falló la conexión");
        }
    }
}
