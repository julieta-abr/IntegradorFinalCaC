package com.example.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.demo.AdministradorDeConexiones;
import com.example.demo.Alumnado;

public class AlumnadoDAO {

    /*MÉTODOS DEL CRUD*/
    public List<Alumnado> listarAlumnos() {
        String sql = "SELECT * FROM ESTUDIANTES ";

        //Connection
        Connection con = AdministradorDeConexiones.getConnection();

        List<Alumnado> list = new ArrayList<>();

        //Statement
        try {
            Statement st = con.createStatement();

            //ResultSet
            ResultSet rs = st.executeQuery(sql);

            //UN SOLO REGISTRO

            while(rs.next()) {
                int Id = rs.getInt(1);
                String Nombre = rs.getString(2);
                String Apellido = rs.getString(3);
                int dni = rs.getInt(4);


                Alumnado alumFromDb = new Alumnado(Id, Nombre, Apellido, dni);

                //Agrego a la lista
                list.add(alumFromDb);
            }

            //Cierro la conexión
            con.close();
        } catch (SQLException e) {
            //ERRORES
            e.printStackTrace();
        }
        return list;
    }

    /*Crear nuevo registro en la DB*/
    public void crearAlumno(int Id, String Nombre, String Apellido, int dni) {

        Connection con = AdministradorDeConexiones.getConnection();

        if(con != null) {
            // insert en la db > SQL: INSERT INTO....
            String sql = "INSERT INTO ESTUDIANTES (Id, Nombre, Apellido, dni) ";
            sql += "VALUES('"+Id+"',"+Nombre+","+Apellido+"','"+dni+"')";

            //Control de errores
            try {
                Statement st = con.createStatement();
                st.execute(sql);

                //Cierre de conexion
                con.close();

            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


}
