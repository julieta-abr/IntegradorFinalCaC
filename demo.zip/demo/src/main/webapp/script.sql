CREATE TABLE estudiantes (
    Id INT(11) NOT NULL AUTO_INCREMENT,
    Nombre VARCHAR(40) NOT NULL,
    Apellido VARCHAR(40) NOT NULL,
    dni INT(8) NOT NULL,

    PRIMARY KEY (Id),
)